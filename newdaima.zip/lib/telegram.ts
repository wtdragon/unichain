function delay(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

export async function sendTelegramBatch(
  chatId: string,
  products: { name: string; link: string; originalPrice: string; salePrice: string }[],
  title: string
) {
  console.log(`📨 Preparing to send Telegram messages (${products.length} items)`);

  const token = process.env.TELEGRAM_BOT_TOKEN!;
  const url = `https://api.telegram.org/bot${token}/sendMessage`;
  const batchSize = Number(process.env.TELEGRAM_BATCH_SIZE || 10);

  const now = new Date();
  const timestamp = now.toLocaleString("en-GB", { hour12: false });

  for (let i = 0; i < products.length; i += batchSize) {
    const group = products.slice(i, i + batchSize);
    const message =
      `🕒 *${title}* — ${timestamp}\n(Total ${group.length} items)\n\n` +
      group
        .map(
          (p, idx) =>
            `${i + idx + 1}. [${p.name}](${p.link})\n💶 Original: ${p.originalPrice || "-"} → Sale: ${p.salePrice || "-"}`
        )
        .join("\n\n");

    let success = false;
    while (!success) {
      try {
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            chat_id: chatId,
            text: message,
            parse_mode: "Markdown",
            disable_web_page_preview: false,
          }),
        });

        const result = await res.json();

        if (result.ok) {
          console.log(`✅ Telegram batch sent (${i + 1}-${i + group.length})`);
          success = true;
          await delay(2000);
        } else if (result.error_code === 429) {
          const wait = (result.parameters?.retry_after || 5) * 1000;
          console.warn(`⏳ Telegram rate limit hit, waiting ${wait / 1000}s`);
          await delay(wait);
        } else {
          console.error("❌ Telegram send failed:", result);
          success = true;
        }
      } catch (err) {
        console.error("🚨 Telegram request error:", err);
        await delay(5000);
      }
    }
  }
}
