import * as dotenv from "dotenv";
dotenv.config({ path: ".env.local" });

import { fetchAllProducts } from "./lib/scraper";
import { sendTelegramBatch } from "./lib/telegram";

let baseline: any[] = [];
let isSending = false;

const URL = "https://outlet.arcteryx.com/de/en/c/mens";

async function checkProducts() {
  if (isSending) {
    console.log("⏳ Previous batch still sending, skipping this round.");
    return;
  }

  console.log("🔍 Checking for product updates...");

  const newList = await fetchAllProducts(URL);
  if (newList.length === 0) {
    console.warn("⚠️ No products fetched, skipping comparison.");
    return;
  }

  if (baseline.length === 0) {
    baseline = newList;
    console.log(`✅ Baseline created with ${newList.length} products.`);
    isSending = true;
    await sendTelegramBatch(
      process.env.TELEGRAM_CHAT_ID!,
      newList,
      "📦 Initial product sync"
    );
    isSending = false;
    return;
  }

  const newItems = newList.filter(
    (p) => !baseline.some((b) => b.link === p.link)
  );
  const changed = newList.filter((p) => {
    const old = baseline.find((b) => b.link === p.link);
    return (
      old &&
      (old.salePrice !== p.salePrice || old.originalPrice !== p.originalPrice)
    );
  });

  if (newItems.length === 0 && changed.length === 0) {
    console.log("✅ No changes detected.");
    return;
  }

  isSending = true;

  if (newItems.length > 0) {
    await sendTelegramBatch(
      process.env.TELEGRAM_CHAT_ID!,
      newItems,
      "🆕 Newly added products"
    );
  }

  if (changed.length > 0) {
    await sendTelegramBatch(
      process.env.TELEGRAM_CHAT_ID!,
      changed,
      "💸 Price changes"
    );
  }

  console.log(
    `📊 Detected: ${newItems.length} new, ${changed.length} price changes.`
  );

  baseline = newList;
  isSending = false;
}

console.log("🚀 Starting Arc'teryx outlet monitor...");
console.log("Using token:", process.env.TELEGRAM_BOT_TOKEN?.slice(0, 10));
console.log("Using chatId:", process.env.TELEGRAM_CHAT_ID);

checkProducts();
setInterval(checkProducts, 1000 * 60 * 6); // every 6 minutes
